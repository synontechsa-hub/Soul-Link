# /backend/app/api/souls.py
# version.py
# _dev/

import logging
import os
from pathlib import Path
from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import FileResponse
from sqlmodel import Session, select, col
from backend.app.database.session import get_session
from backend.app.models.soul import Soul
from backend.app.models.user import User
from backend.app.models.relationship import SoulRelationship
from backend.app.api.dependencies import get_current_user 

router = APIRouter(prefix="/souls", tags=["Legion Engine - Souls"])
logger = logging.getLogger("LegionEngine")

# 🎨 PORTRAIT MANAGER
class PortraitManager:
    """
    Backend brain for soul portraits.
    Decides which portrait to serve based on context.
    """
    
    @staticmethod
    def get_portrait_path(soul: Soul, variant: str = "01", context: dict = None) -> Path:
        """
        Smart portrait selection logic.
        
        Args:
            soul: The Soul object
            variant: Portrait variant ('01', '02', etc.)
            context: Optional context (location, intimacy_tier, etc.)
        
        Returns:
            Path to the portrait file
        """
        # Base assets directory
        assets_dir = Path(__file__).parent.parent.parent.parent / "assets" / "souls" / "stable_diffusion"
        
        # Convert soul name to filename format
        soul_name = soul.name.lower().replace(' ', '_')
        
        # 🧠 SMART SELECTION: Choose variant based on context
        if context:
            variant = PortraitManager._select_variant(soul, context)
        
        # Build path
        portrait_path = assets_dir / f"{soul_name}_{variant}.jpeg"
        
        # Fallback to default if specific variant doesn't exist
        if not portrait_path.exists():
            portrait_path = assets_dir / f"{soul_name}_01.jpeg"
        
        # Ultimate fallback: placeholder
        if not portrait_path.exists():
            portrait_path = assets_dir / "placeholder.jpeg"
        
        return portrait_path
    
    @staticmethod
    def _select_variant(soul: Soul, context: dict) -> str:
        """
        Decide which portrait variant to show based on context.
        This is where the MAGIC happens!
        """
        location = context.get("location", "")
        tier = context.get("intimacy_tier", "STRANGER")
        
        # 🌙 Selene: Different look at night locations
        if soul.soul_id == "SOUL-008":
            if "ether" in location.lower() or "skylink" in location.lower():
                return "02"  # Ethereal goddess look
        
        # 💋 Evangeline: Gothic look for private locations
        if soul.soul_id == "SOUL-004":
            if location == "dollhouse_dungeon" or tier == "SOUL_LINKED":
                return "02"  # More intimate/gothic look
        
        # 🔥 Default: Use main portrait
        return "01"
    
    @staticmethod
    def get_portrait_url(soul_id: str, variant: str = "01") -> str:
        """Returns the API URL for fetching a portrait"""
        return f"/api/v1/souls/{soul_id}/portrait?variant={variant}"


@router.get("/explore")
def explore_souls(
    user: User = Depends(get_current_user), 
    db: Session = Depends(get_session)
):
    """
    Browse ALL souls in Link City (Character.AI style).
    Shows which ones you're already linked with vs. available to link.
    """
    try:
        # 1. Get all existing relationships for this user
        linked_statement = select(SoulRelationship).where(
            SoulRelationship.user_id == user.user_id
        )
        relationships = db.exec(linked_statement).all()
        
        # Create a lookup dict: {soul_id: relationship}
        linked_dict = {rel.soul_id: rel for rel in relationships}

        # 2. Get ALL souls
        all_souls = db.exec(select(Soul)).all()
        
        output = []
        for s in all_souls:
            rel = linked_dict.get(s.soul_id)
            
            soul_data = {
                "id": s.soul_id,
                "name": s.name,
                "tagline": s.summary[:100] + "..." if len(s.summary) > 100 else s.summary,
                "archetype": s.archetype or "Unknown",
                "is_linked": rel is not None,
                # 🎨 NEW: Backend provides the portrait URL
                "portrait_url": PortraitManager.get_portrait_url(s.soul_id),
            }
            
            # If linked, include relationship info
            if rel:
                soul_data["intimacy_tier"] = rel.intimacy_tier
                soul_data["current_location"] = rel.current_location
                soul_data["is_architect"] = rel.is_architect
                # 🎨 Smart portrait: Changes based on context
                soul_data["portrait_url"] = PortraitManager.get_portrait_url(
                    s.soul_id,
                    variant=PortraitManager._select_variant(s, {
                        "location": rel.current_location,
                        "intimacy_tier": rel.intimacy_tier
                    })
                )
            
            output.append(soul_data)
        
        return output
        
    except Exception as e:
        logger.error(f"Phoenix Explore Error: {e}")
        raise HTTPException(status_code=500, detail="Failed to scout for souls.")


@router.get("/{soul_id}/portrait")
async def get_soul_portrait(
    soul_id: str,
    variant: str = "01",
    db: Session = Depends(get_session)
):
    """
    Serve the actual portrait image file.
    Backend decides which image to serve!
    """
    soul = db.get(Soul, soul_id)
    if not soul:
        raise HTTPException(404, detail=f"Soul {soul_id} not found.")
    
    # Get the portrait path
    portrait_path = PortraitManager.get_portrait_path(soul, variant)
    
    if not portrait_path.exists():
        raise HTTPException(404, detail="Portrait not found.")
    
    # Serve the image
    return FileResponse(
        portrait_path,
        media_type="image/jpeg",
        headers={
            "Cache-Control": "public, max-age=86400",  # Cache for 1 day
        }
    )


@router.get("/{soul_id}")
def get_soul_details(soul_id: str, db: Session = Depends(get_session)):
    """Get detailed public profile info about a specific soul."""
    soul = db.get(Soul, soul_id)
    if not soul:
        raise HTTPException(404, detail=f"Soul {soul_id} not found.")
    
    return {
        "id": soul.soul_id,
        "name": soul.name,
        "summary": soul.summary,
        "archetype": soul.archetype,
        "appearance": soul.aesthetic_pillar.get("description", ""),
        "voice_style": soul.aesthetic_pillar.get("voice_style", ""),
        "signature_emote": soul.aesthetic_pillar.get("signature_emote", ""),
        # 🎨 NEW: Portrait URL
        "portrait_url": PortraitManager.get_portrait_url(soul_id),
    }


@router.post("/{soul_id}/link")
async def link_with_soul(
    soul_id: str,
    user: User = Depends(get_current_user), 
    session: Session = Depends(get_session)
):
    """Initialize a relationship with a soul for a verified user."""
    soul = session.get(Soul, soul_id)
    if not soul:
        raise HTTPException(404, detail=f"Soul {soul_id} not found.")
    
    existing = session.exec(
        select(SoulRelationship).where(
            SoulRelationship.user_id == user.user_id,
            SoulRelationship.soul_id == soul_id
        )
    ).first()
    
    if existing:
        return {
            "status": "already_linked",
            "soul_id": soul_id,
            "soul_name": soul.name,
            "intimacy_tier": existing.intimacy_tier
        }
    
    # Create new relationship
    new_rel = SoulRelationship(
        user_id=user.user_id,
        soul_id=soul_id,
        intimacy_score=0,
        intimacy_tier="STRANGER",
        current_location="soul_plaza"
    )
    
    # 🕵️ ARCHITECT CHECK
    if user.user_id == "USR-001":
        new_rel.is_architect = True
        new_rel.nsfw_unlocked = True
    
    session.add(new_rel)
    session.commit()
    session.refresh(new_rel)
    
    return {
        "status": "linked",
        "soul_id": soul_id,
        "soul_name": soul.name,
        "message": f"Link established. Welcome to the city, {soul.name}."
    }


@router.get("/{soul_id}/relationship")
async def get_relationship_status(
    soul_id: str,
    user: User = Depends(get_current_user), 
    session: Session = Depends(get_session)
):
    """Check your current relationship status with a soul."""
    rel = session.exec(
        select(SoulRelationship).where(
            SoulRelationship.user_id == user.user_id,
            SoulRelationship.soul_id == soul_id
        )
    ).first()
    
    if not rel:
        raise HTTPException(404, detail=f"No relationship with {soul_id}.")
    
    return {
        "soul_id": soul_id,
        "intimacy_score": rel.intimacy_score,
        "intimacy_tier": rel.intimacy_tier,
        "current_location": rel.current_location,
        "is_architect": rel.is_architect,
        "nsfw_unlocked": rel.nsfw_unlocked
    }
