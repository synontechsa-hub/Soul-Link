// frontend/lib/widgets/soul_card.dart
// version.py
// _dev/
// BACKEND-DRIVEN ARCHITECTURE: Flutter is just the pretty face!

import 'package:flutter/material.dart';
import '../models/relationship.dart';

class SoulCard extends StatelessWidget {
  final SoulRelationship relationship;
  final VoidCallback onTap;

  const SoulCard({super.key, required this.relationship, required this.onTap});

  @override
  Widget build(BuildContext context) {
    // 🎭 Dynamic coloring based on the Link status
    bool isHighLink = relationship.intimacy_tier == "SOUL_LINKED";
    Color tierColor = isHighLink ? Colors.cyanAccent : Colors.white70;

    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 6),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: const Color(0xFF1A1A22),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: isHighLink ? Colors.cyanAccent.withOpacity(0.4) : Colors.white10, 
            width: 1
          ),
          boxShadow: [
            if (isHighLink)
              BoxShadow(
                color: Colors.cyanAccent.withOpacity(0.05),
                blurRadius: 15,
                spreadRadius: 2,
              )
          ],
        ),
        child: Row(
          children: [
            // 🖼️ PORTRAIT ZONE - Backend tells us what to show!
            _buildPortrait(tierColor),
            
            const SizedBox(width: 16),
            
            // 📝 INFO ZONE
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          relationship.name.toUpperCase(),
                          style: TextStyle(
                            color: tierColor,
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                            letterSpacing: 1.5,
                          ),
                        ),
                      ),
                      if (relationship.isArchitect)
                        const Tooltip(
                          message: "Architect Authorized",
                          child: Icon(Icons.verified, color: Colors.amber, size: 16),
                        ),
                    ],
                  ),
                  const SizedBox(height: 2),
                  Text(
                    relationship.archetype.toUpperCase(),
                    style: const TextStyle(
                      color: Colors.cyanAccent, 
                      fontSize: 9, 
                      fontWeight: FontWeight.bold,
                      letterSpacing: 1
                    ),
                  ),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      const Icon(Icons.location_on, color: Colors.white24, size: 10),
                      const SizedBox(width: 4),
                      Expanded(
                        child: Text(
                          relationship.currentLocation.replaceAll('_', ' ').toUpperCase(),
                          style: const TextStyle(color: Colors.white38, fontSize: 10),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),

            // ⚡ TIER INDICATOR
            _buildTierBadge(),
          ],
        ),
      ),
    );
  }

  Widget _buildPortrait(Color tierColor) {
    // 🧠 BACKEND-DRIVEN: Just display what backend tells us!
    // Backend handles all the smart logic:
    // - Which variant to show
    // - Location-based changes
    // - Intimacy-based unlocks
    // - Fallbacks if image missing
    
    final baseUrl = 'http://localhost:8000'; // TODO: Move to config
    final portraitUrl = relationship.portraitUrl ?? '/api/v1/souls/${relationship.soulId}/portrait';
    final fullUrl = portraitUrl.startsWith('http') ? portraitUrl : '$baseUrl$portraitUrl';
    
    return Container(
      width: 55,
      height: 55,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        border: Border.all(color: tierColor.withOpacity(0.5), width: 2),
        color: const Color(0xFF0A0A0E),
      ),
      child: ClipOval(
        child: Image.network(
          fullUrl,
          fit: BoxFit.cover,
          loadingBuilder: (context, child, loadingProgress) {
            if (loadingProgress == null) return child;
            return _buildLoadingIndicator();
          },
          errorBuilder: (context, error, stackTrace) {
            // Fallback if network error
            return _buildFallbackIcon(tierColor);
          },
        ),
      ),
    );
  }

  Widget _buildLoadingIndicator() {
    return Container(
      color: const Color(0xFF0A0A0E),
      child: const Center(
        child: CircularProgressIndicator(
          strokeWidth: 2,
          valueColor: AlwaysStoppedAnimation<Color>(Colors.cyanAccent),
        ),
      ),
    );
  }

  Widget _buildFallbackIcon(Color tierColor) {
    return Icon(
      Icons.person,
      color: tierColor.withOpacity(0.7),
      size: 30,
    );
  }

  Widget _buildTierBadge() {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        const Text(
          "TIER", 
          style: TextStyle(
            color: Colors.white10, 
            fontSize: 8, 
            fontWeight: FontWeight.bold
          )
        ),
        Text(
          relationship.intimacyTier.split('_').last, 
          style: const TextStyle(
            color: Colors.white38, 
            fontSize: 10, 
            fontWeight: FontWeight.bold
          )
        ),
      ],
    );
  }
}
