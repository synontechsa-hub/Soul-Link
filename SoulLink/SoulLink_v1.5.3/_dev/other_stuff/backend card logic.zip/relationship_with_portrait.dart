// frontend/lib/models/relationship.dart
// version.py
// _dev/
// BACKEND-DRIVEN: Backend tells us everything, including portrait URLs!

class SoulRelationship {
  final String soulId;
  final String name;
  final String archetype;
  final String currentLocation;
  final String intimacyTier;
  final int intimacyScore;
  final bool isArchitect;
  final bool nsfwUnlocked;
  final String lastInteraction;
  // 🎨 NEW: Backend provides the portrait URL
  final String? portraitUrl;

  SoulRelationship({
    required this.soulId,
    required this.name,
    required this.archetype,
    required this.currentLocation,
    required this.intimacyTier,
    required this.intimacyScore,
    required this.isArchitect,
    required this.nsfwUnlocked,
    required this.lastInteraction,
    this.portraitUrl, // Optional, backend might not always send it
  });

  factory SoulRelationship.fromJson(Map<String, dynamic> json) {
    return SoulRelationship(
      soulId: json['soul_id'],
      name: json['name'] ?? "Unknown", 
      archetype: json['archetype'] ?? "Unknown",
      currentLocation: json['location'] ?? "Unknown",
      intimacyTier: json['tier'] ?? "STRANGER",
      intimacyScore: json['intimacy_score'] ?? 0,
      isArchitect: json['is_architect'] ?? false,
      nsfwUnlocked: json['nsfw_unlocked'] ?? false,
      lastInteraction: json['last_interaction'] ?? "",
      // 🎨 NEW: Parse portrait URL from backend
      portraitUrl: json['portrait_url'],
    );
  }
}
