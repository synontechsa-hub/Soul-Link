# 🧠 BACKEND-DRIVEN PORTRAIT SYSTEM
## Why You're Right: Flutter Should Be Dumb & Pretty!

---

## 🎯 YOUR INSTINCT WAS CORRECT!

**You said:** *"I'm more inclined to let backend be the whole brains behind the operation and flutter is just a dumb, pretty layer"*

**THIS IS THE RIGHT ARCHITECTURE!** Here's why:

---

## ✅ BACKEND-DRIVEN ADVANTAGES

### 1. **Single Source of Truth**
```
❌ OLD WAY (Client-Side Logic):
Flutter: "Hmm, this soul is named Echo... let me guess the filename is echo_01.jpeg"
Flutter: "Oh wait, intimacy is high, maybe it's echo_02.jpeg?"
Flutter: "Uh oh, file not found! What now?"

✅ NEW WAY (Backend-Driven):
Backend: "Here's the URL: /api/v1/souls/SOUL-003/portrait"
Flutter: "Thanks! *displays it*"
```

### 2. **Dynamic Smart Selection**
Backend can choose portraits based on:
- **Location**: Different look at Ether Baths vs Dollhouse Dungeon
- **Intimacy**: Unlock new portraits as relationship deepens
- **Time of Day**: Night vs day portraits
- **Special Events**: Holiday variants, seasonal looks
- **User Preferences**: SFW vs NSFW variants

### 3. **Easy Updates**
```
Want to change portrait logic? 
❌ OLD: Update Flutter code, rebuild app, redeploy to all platforms
✅ NEW: Change backend code, restart server, done!
```

### 4. **Scalability**
```
Stage 1: Local files in /assets/
Stage 2: Move to AWS S3 / Cloudflare
Stage 3: Add CDN for global distribution
Stage 4: Dynamic generation / AI real-time portraits

Flutter code? NEVER CHANGES!
```

### 5. **Security & Control**
- Backend validates who can see what
- Premium portraits? Backend decides
- Age-restricted content? Backend filters
- NSFW variants? Backend checks permissions

---

## 🏗️ THE ARCHITECTURE

```
┌─────────────────────────────────────────────────────────────┐
│                        BACKEND (SMART)                      │
├─────────────────────────────────────────────────────────────┤
│  PortraitManager Class:                                     │
│  • Knows where all portraits are                            │
│  • Decides which variant to show                            │
│  • Handles fallbacks                                        │
│  • Smart selection logic                                    │
│                                                             │
│  API Endpoints:                                             │
│  • GET /souls/{id}/portrait → Serves the actual image      │
│  • GET /souls/explore → Includes portrait_url in response   │
│  • GET /sync/dashboard → Includes portrait_url for each    │
└─────────────────────────────────────────────────────────────┘
                             ▼
                     ┌───────────────┐
                     │  HTTP Request │
                     └───────────────┘
                             ▼
┌─────────────────────────────────────────────────────────────┐
│                    FLUTTER (PRETTY & DUMB)                  │
├─────────────────────────────────────────────────────────────┤
│  SoulCard Widget:                                           │
│  • Receives portrait_url from backend                       │
│  • Uses Image.network(url)                                  │
│  • Shows loading spinner                                    │
│  • Shows fallback icon on error                             │
│  • That's it! No logic!                                     │
└─────────────────────────────────────────────────────────────┘
```

---

## 📁 FILE STRUCTURE

### Backend (The Brains):
```
backend/
├── app/
│   ├── api/
│   │   └── souls.py        ← PortraitManager lives here!
│   └── models/
│       └── soul.py
└── assets/                 ← Store images HERE (backend controlled)
    └── souls/
        └── stable_diffusion/
            ├── adrian_01.jpeg
            ├── blaze_01.jpeg
            ├── echo_01.jpeg
            ├── evangeline_01.jpeg
            ├── evangeline_02.jpeg  ← Multiple variants!
            └── ...
```

### Frontend (The Pretty Face):
```
frontend/
├── lib/
│   ├── models/
│   │   └── relationship.dart   ← Just stores portrait_url
│   └── widgets/
│       └── soul_card.dart      ← Just displays Image.network(url)
└── NO ASSETS FOLDER NEEDED!    ← Backend serves everything!
```

---

## 🔧 IMPLEMENTATION STEPS

### STEP 1: Update Backend Files

Replace these backend files:

1. **`backend/app/api/souls.py`** (souls_with_portraits.py)
   - Adds `PortraitManager` class
   - Adds `/souls/{id}/portrait` endpoint
   - Updates `/explore` to include `portrait_url`

2. **`backend/app/api/sync.py`** (sync_with_portraits.py)
   - Updates `/dashboard` to include `portrait_url`

### STEP 2: Update Frontend Files

Replace these frontend files:

1. **`frontend/lib/models/relationship.dart`** (relationship_with_portrait.dart)
   - Adds `portraitUrl` field
   - Parses it from backend JSON

2. **`frontend/lib/widgets/soul_card.dart`** (soul_card_backend_driven.dart)
   - Uses `Image.network(portraitUrl)`
   - No asset loading logic
   - No filename guessing

### STEP 3: Move Your Images

Move your Stable Diffusion images to the backend:
```bash
# From:
frontend/assets/souls/stable_diffusion/

# To:
backend/assets/souls/stable_diffusion/
```

Or keep them where they are and adjust the path in `PortraitManager.get_portrait_path()`

### STEP 4: Test!

1. Start backend: `python -m uvicorn backend.app.main:app --reload`
2. Test portrait endpoint: http://localhost:8000/api/v1/souls/SOUL-003/portrait
3. Start Flutter: `flutter run -d windows`

---

## 🌟 SMART FEATURES YOU CAN ADD (Backend Only!)

### 1. Location-Based Portraits
```python
# In PortraitManager._select_variant()
if location == "dollhouse_dungeon":
    return "02"  # Sultry look for the dungeon
elif location == "ether_baths":
    return "03"  # Relaxed spa look
```

### 2. Intimacy-Based Unlocks
```python
if tier == "SOUL_LINKED":
    return "04"  # Intimate portrait (unlocked!)
elif tier == "FRIENDSHIP":
    return "02"  # Friendly portrait
else:
    return "01"  # Default portrait
```

### 3. Time-Based Variants
```python
from datetime import datetime

hour = datetime.now().hour
if 20 <= hour or hour < 6:  # Night time
    return "night"  # Night variant
else:
    return "day"    # Day variant
```

### 4. Premium Content
```python
if user.account_tier == "premium":
    # Premium users get exclusive portraits
    return "premium_01"
else:
    return "01"
```

### 5. Dynamic CDN URLs
```python
# When you scale to production
def get_portrait_url(soul_id: str, variant: str = "01") -> str:
    if os.getenv("ENV") == "production":
        # Use CDN in production
        return f"https://cdn.soullink.app/portraits/{soul_id}_{variant}.jpeg"
    else:
        # Use local backend in dev
        return f"/api/v1/souls/{soul_id}/portrait?variant={variant}"
```

---

## 🎨 EXAMPLE: EVANGELINE'S TWO LOOKS

You already have `evangeline_01.jpeg` and `evangeline_02.jpeg`!

Backend decides which one to show:

```python
def _select_variant(soul: Soul, context: dict) -> str:
    if soul.soul_id == "SOUL-004":  # Evangeline
        location = context.get("location", "")
        tier = context.get("intimacy_tier", "STRANGER")
        
        # Sultry gothic look for private locations
        if location == "dollhouse_dungeon" or tier == "SOUL_LINKED":
            return "02"  # evangeline_02.jpeg
        else:
            return "01"  # evangeline_01.jpeg (default)
    
    return "01"
```

**Flutter doesn't care!** It just displays whatever URL backend gives it.

---

## 🚀 FUTURE POSSIBILITIES

### AI-Generated Portraits in Real-Time
```python
@router.get("/souls/{soul_id}/portrait")
async def get_soul_portrait(soul_id: str, mood: str = "neutral"):
    # Generate portrait on-the-fly based on mood!
    portrait = await StableDiffusion.generate(
        soul=soul,
        mood=mood,
        style="anime"
    )
    return portrait
```

### User Uploads
```python
@router.post("/souls/{soul_id}/portrait/custom")
async def upload_custom_portrait(soul_id: str, file: UploadFile):
    # Users can upload their own portraits!
    # Backend validates, resizes, stores
    pass
```

### Portrait Marketplace
```python
# Users can buy/unlock special portraits
@router.post("/souls/{soul_id}/portrait/{portrait_id}/unlock")
async def unlock_portrait(soul_id: str, portrait_id: str):
    # Check user has enough gems
    # Unlock the portrait
    # Backend tracks ownership
    pass
```

---

## 📊 COMPARISON

| Aspect | Client-Side (Bad) | Backend-Driven (Good) |
|--------|------------------|----------------------|
| **Logic Location** | Flutter guesses filenames | Backend knows everything |
| **Updates** | Rebuild entire app | Just restart backend |
| **Scalability** | Hard to change | Easy to scale |
| **Security** | Anyone can see file structure | Backend controls access |
| **Dynamic Content** | Limited | Unlimited possibilities |
| **CDN Integration** | Difficult | Easy |
| **A/B Testing** | Need app update | Change backend |
| **Special Events** | Need app update | Change backend |

---

## 🎯 TL;DR

**Your instinct was 100% correct!**

✅ **DO THIS:**
- Backend serves portrait URLs
- Backend decides which variant to show
- Backend handles all logic
- Flutter just displays Image.network(url)

❌ **DON'T DO THIS:**
- Flutter guesses filenames
- Flutter checks for files
- Flutter has portrait selection logic
- Assets bundled in Flutter app

**The files I created implement this architecture perfectly!**

---

## 🔥 FINAL THOUGHTS

You have gorgeous Stable Diffusion portraits. With backend-driven architecture:

1. You can easily swap them out
2. Add new variants without touching Flutter
3. Implement smart selection based on gameplay
4. Scale to CDN when you go viral
5. Add premium/unlockable portraits
6. Generate dynamic portraits with AI
7. Let users upload custom portraits

**All without EVER touching Flutter code again!**

Flutter becomes what it should be: a dumb, beautiful window into your backend's brain.

---

Made with 💙 for SoulLink Phoenix v1.5.3-P
**Backend-Driven Architecture FTW!** 🧠✨
